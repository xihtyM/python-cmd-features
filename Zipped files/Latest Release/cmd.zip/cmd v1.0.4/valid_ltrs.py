# List of all valid letters
validLetters = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!≥≤£$%^&*()-+_=[]{}'#@~;:<>,./?|\`¬"+'"“’”'+"\n"+"\t"+"™ƒ€µ©®œŽŒ‰÷æ¼½•"+"ÿÛâàØüÌÓ·…¶Ïé‰¿ËöJ"+""+""+""+"Ü"+"§š¥›±ª¦çå‡þ";
validLetters += "";

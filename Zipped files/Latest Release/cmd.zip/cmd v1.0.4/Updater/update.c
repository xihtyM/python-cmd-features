/* Use to update cmd to latest version */

/* Includes */

#include <stdio.h>

#include "extras.h"
#include "os.h"
#include "str.h"

int main(void) {
	printf("Scanning for valid files.");
	const char * CURRENT_DIR = getdir();
	printf("%s", CURRENT_DIR);
	system("pause");
}

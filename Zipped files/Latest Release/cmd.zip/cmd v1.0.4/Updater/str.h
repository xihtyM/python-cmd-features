/* Defines and functions */

#include <stdlib.h>

#ifndef __STRING_H
	#define __STRING_H

	int length(const char * __s) {
		int i;
		for (i = 0; __s[i] != '\0'; ++i);
		return i;
	}

	/*
	FIX: CONCAT FUNCTION RETURNS POINTER TO NULL ADDRESS
	char * concat(char * __dest, const char * __str)
	{
		int __dest_len = length(__dest);
		char __dest_t[__dest_len + length(__str)];
		
		for(int c = 0; c < __dest_len; c++) {
			__dest_t[c] = __dest[c];
		}
		
		for(int i = 0; i < length(__str); i++) {
			__dest_t[__dest_len + i] = __str[i];
		}
		
		__dest_t[length(__dest_t)-1] = '\0';
		__dest = __dest_t;
		// FIX: BROKEN RETURN
	}
	*/

	/* Replace char in string */

	char * replace(char * string, char chr1, char chr2) {
		int i;
		char * FULL_STR = malloc(length(string)+1);

		for(i=0; string[i]; i++) {
			if(string[i] == chr1) {
				FULL_STR[i] = chr2;
			} else {
				FULL_STR[i] = string[i];
			}
		}

		/* Terminate string */

		FULL_STR[length(string)] = '\0';

		return FULL_STR;

		/* Remember to free after using */
	}
#endif

/* C/C++ Extras Library (Bools) */

#ifndef __EXTRAS_H

    #define __EXTRAS_H

    /* True/False/Bool */

    #if !defined(__cplusplus) && !defined(__STDBOOL_H) && !defined(NO_BOOLS) && !defined(__BOOL_H)
        #define __BOOL_H

        #ifdef bool
            #undef bool
        #endif

        #ifdef true
            #undef true
        #endif

        #ifdef false
            #undef false
        #endif

        #define bool _Bool
        #define true 1
        #define false 0

        #define true_false_defined true
    #endif
#endif

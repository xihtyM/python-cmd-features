import sys, os;
def getcwd():
    return os.path.dirname(os.path.realpath(sys.argv[0]));

def compile(code):
	print(code);
